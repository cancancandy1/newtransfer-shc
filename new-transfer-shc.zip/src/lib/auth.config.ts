import type { NextAuthConfig } from "next-auth";

// Base path ของแอป — ใช้ hardcode เพื่อความแน่นอนใน production
const BASE_PATH = "/new-transfer";

// Base auth config — ใช้ทั้งใน middleware (Edge) และ auth.ts (Node.js)
// ห้าม import Prisma ที่นี่ เพราะ Edge runtime ไม่รองรับ
export const authConfig: NextAuthConfig = {
  trustHost: true,
  // บอก Auth.js ว่า endpoint อยู่ที่ /new-transfer/api/auth
  basePath: `${BASE_PATH}/api/auth`,
  pages: {
    // Next.js จะ prepend basePath ให้อัตโนมัติ → /new-transfer/login
    signIn: "/login",
  },
  session: { strategy: "jwt" },
  callbacks: {
    // ตรวจสอบสิทธิ์เข้าถึง — ทำงานใน Edge middleware
    // หมายเหตุ: เมื่อตั้ง basePath ใน next.config → nextUrl.pathname จะ strip basePath แล้ว
    authorized({ auth, request: { nextUrl } }) {
      const isLoggedIn = !!auth?.user;
      // pathname ที่ได้จะเป็น /admin/... (basePath ถูก strip แล้วโดย Next.js)
      const isAdminPage = nextUrl.pathname.startsWith("/admin");

      // ถ้าไม่ได้ login ให้ redirect ไปหน้า login
      if (isAdminPage && !isLoggedIn) return false;

      // ตรวจสอบ RBAC: เฉพาะ role=ADMIN ที่เข้า /admin/admins ได้
      if (nextUrl.pathname.startsWith("/admin/admins")) {
        const role = (auth?.user as { role?: string })?.role;
        if (role !== "ADMIN") {
          // redirect กลับ /admin (Next.js prepend basePath ให้อัตโนมัติ)
          return Response.redirect(new URL(`${BASE_PATH}/admin`, nextUrl.origin));
        }
      }

      return true;
    },

    // บันทึก firstname, lastname, role ลง JWT token (ปลอดภัยใน Edge)
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    jwt({ token, user }: { token: any; user: any }) {
      if (user) {
        token.id = user.id;
        token.firstname = user.firstname;
        token.lastname = user.lastname;
        token.role = user.role;
      }
      return token;
    },

    // ส่ง firstname, lastname, role ไปยัง session object (ปลอดภัยใน Edge)
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    session({ session, token }: { session: any; token: any }) {
      session.user.id = token.id as string;
      session.user.firstname = token.firstname as string;
      session.user.lastname = token.lastname as string;
      session.user.role = token.role as "ADMIN" | "STAFF";
      return session;
    },
  },
  providers: [], // providers อยู่ใน auth.ts (Node.js only)
};
